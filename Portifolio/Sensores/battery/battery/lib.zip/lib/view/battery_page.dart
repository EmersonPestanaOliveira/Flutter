import 'dart:async';
import 'package:battery/utils/battery_state_styles.dart';
import 'package:battery/widgets/battery_meter.dart';
import 'package:battery/widgets/battery_status_chip.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:flutter/material.dart';

class BatteryPage extends StatefulWidget {
  const BatteryPage({super.key});

  @override
  State<BatteryPage> createState() => _BatteryPageState();
}

class _BatteryPageState extends State<BatteryPage> {
  final _battery = Battery();
  int? _level;
  BatteryState? _state;
  StreamSubscription<BatteryState>? _sub;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _fetchLevel();
    _sub = _battery.onBatteryStateChanged.listen((s) {
      setState(() => _state = s);
      _fetchLevel();
    });
    _poll = Timer.periodic(const Duration(seconds: 10), (_) => _fetchLevel());
  }

  Future<void> _fetchLevel() async {
    try {
      final level = await _battery.batteryLevel;
      if (!mounted) return;
      setState(() => _level = level);
    } catch (_) {}
  }

  @override
  void dispose() {
    _sub?.cancel();
    _poll?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final level = _level;
    final percentText = level == null ? '--' : '$level%';
    final st = _state;

    final (label, color, icon) = styleForBatteryState(st);
    final showPowerIcon =
        st == BatteryState.charging || st == BatteryState.connectedNotCharging;

    return Scaffold(
      appBar: AppBar(title: const Text('Nível de Bateria')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            BatteryMeter(
              level: level,
              color: color,
              showPowerIcon: showPowerIcon,
            ),
            const SizedBox(height: 12),
            Text(
              percentText,
              style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            BatteryStatusChip(label: label, color: color, icon: icon),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _fetchLevel,
              icon: const Icon(Icons.refresh),
              label: const Text('Atualizar agora'),
            ),
          ],
        ),
      ),
    );
  }
}
