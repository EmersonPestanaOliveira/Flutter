package com.example.micro_app_home

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
