import 'package:flutter/material.dart';
import 'base_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final microApps = [
    MicroAppHome(),
  ];

  final mergedRoutes = <String, WidgetBuilder>{};
  for (final m in microApps) {
    mergedRoutes.addAll(m.routes);
  }

  final initialRoute = MicroAppHome().initialRoute;

  runApp(BaseApp(
    initialRoute: initialRoute,
    routes: mergedRoutes,
  ));
}
