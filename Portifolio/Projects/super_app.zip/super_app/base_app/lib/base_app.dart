import 'package:flutter/material.dart';

class BaseApp extends StatelessWidget {
  final String initialRoute;
  final Map<String, WidgetBuilder> routes;

  const BaseApp({
    super.key,
    required this.initialRoute,
    required this.routes,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Super App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      initialRoute: initialRoute,
      routes: routes,
    );
  }
}
