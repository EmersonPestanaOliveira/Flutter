import '../../../../core/database/app_database.dart';

/// Wrapper sobre o DAO SQLite, sem logica de negocio.
/// Existe para desacoplar o sync worker e o repositorio da persistencia local.
abstract interface class OcorrenciaLocalDatasource {
  Stream<List<PendingOcorrencia>> watchPending();
  Future<List<PendingOcorrencia>> getPendingForSync();
  Future<void> enqueue(PendingOcorrenciasCompanion entry);
  Future<void> markSyncing(String clientId);
  Future<void> markSynced(String clientId);
  Future<void> markFailed(String clientId, String error);
  Future<void> resetStaleSyncing();
  Future<void> purgeSynced();

  /// Recoloca um item em [PendingStatus.queued] zerando o contador de tentativas.
  /// Usado para retry manual pelo usuário.
  Future<void> resetToQueued(String clientId);
}

class OcorrenciaLocalDatasourceImpl implements OcorrenciaLocalDatasource {
  const OcorrenciaLocalDatasourceImpl(this._dao);

  final PendingOcorrenciasDao _dao;

  @override
  Stream<List<PendingOcorrencia>> watchPending() => _dao.watchPending();

  @override
  Future<List<PendingOcorrencia>> getPendingForSync() =>
      _dao.getPendingForSync();

  @override
  Future<void> enqueue(PendingOcorrenciasCompanion entry) =>
      _dao.enqueue(entry);

  @override
  Future<void> markSyncing(String clientId) => _dao.markSyncing(clientId);

  @override
  Future<void> markSynced(String clientId) => _dao.markSynced(clientId);

  @override
  Future<void> markFailed(String clientId, String error) =>
      _dao.markFailed(clientId, error);

  @override
  Future<void> resetStaleSyncing() => _dao.resetStaleSyncing();

  @override
  Future<void> purgeSynced() => _dao.purgeSynced();

  @override
  Future<void> resetToQueued(String clientId) => _dao.resetToQueued(clientId);
}
