import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../../core/errors/failure_x.dart';
import '../../../../core/geo/geo_utils.dart';
import '../../../../core/observability/telemetry.dart';
import '../../../../core/types/app_result.dart';
import '../../../../core/usecases/usecase.dart';
import '../../domain/entities/alerta.dart';
import '../../domain/entities/alerta_filter.dart';
import '../../domain/entities/camera.dart';
import '../../domain/usecases/get_alertas_in_bounds_usecase.dart';
import '../../domain/usecases/get_alertas_usecase.dart';
import '../../domain/usecases/get_cameras_usecase.dart';
import 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit(
    this.getCamerasUseCase,
    this.getAlertasUseCase,
    this.getAlertasInBoundsUseCase,
    this._telemetry,
  ) : super(const HomeInitial());

  final GetCamerasUseCase getCamerasUseCase;
  final GetAlertasUseCase getAlertasUseCase;
  final GetAlertasInBoundsUseCase getAlertasInBoundsUseCase;
  final Telemetry _telemetry;

  bool _initialAlertMapEnabled = true;
  Timer? _cameraIdleDebounce;

  // Cache para evitar re-fetch com mesmo bounds+zoom+filter
  GeoBounds? _lastBounds;
  double? _lastZoom;
  AlertaFilter? _lastFilter;

  Future<void> loadData() async {
    emit(const HomeLoading());
    final loadStart = DateTime.now().millisecondsSinceEpoch;

    final results = await Future.wait([
      getCamerasUseCase(const NoParams()),
      getAlertasUseCase(const NoParams()),
    ]);

    final camerasResult = results[0] as AppResult<List<Camera>>;
    final alertasResult = results[1] as AppResult<List<Alerta>>;

    final cameras = camerasResult.fold<List<Camera>?>(
      (failure) {
        emit(HomeError(message: failure.message));
        return null;
      },
      (data) => data,
    );

    if (cameras == null) return;

    final alertas = alertasResult.fold<List<Alerta>>(
      (failure) {
        if (kDebugMode) {
          debugPrint('[HomeCubit] Falha ao carregar alertas: ${failure.message}');
        }
        return const <Alerta>[];
      },
      (data) => data,
    );

    final elapsed = DateTime.now().millisecondsSinceEpoch - loadStart;
    _telemetry.log(
      'map.initial_load',
      params: {
        'pinCount': alertas.length,
        'elapsedMs': elapsed,
      },
    );

    emit(
      HomeLoaded(
        cameras: cameras,
        alertas: alertas,
        isAlertMapEnabled: _initialAlertMapEnabled,
      ),
    );
  }

  void changeTab(int index) {
    final currentState = state;
    if (currentState is! HomeLoaded) return;
    emit(currentState.copyWith(tabIndex: index));
  }

  void setAlertMapEnabled(bool isEnabled) {
    final currentState = state;
    if (currentState is! HomeLoaded) {
      _initialAlertMapEnabled = isEnabled;
      return;
    }
    _initialAlertMapEnabled = isEnabled;
    emit(
      currentState.copyWith(
        isAlertMapEnabled: isEnabled,
        tabIndex: isEnabled ? currentState.tabIndex : 0,
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Seleção de alerta (pin individual)
  // ---------------------------------------------------------------------------

  void selectAlerta(Alerta alerta) {
    final currentState = state;
    if (currentState is! HomeLoaded) return;
    _telemetry.log('map.pin_tapped', params: {'alertaId': alerta.id});
    emit(currentState.copyWith(selectedAlerta: alerta));
  }

  void clearSelectedAlerta() {
    final currentState = state;
    if (currentState is! HomeLoaded) return;
    emit(currentState.copyWith(selectedAlerta: null));
  }

  void onClusterTapped(double clusterLat, double clusterLon) {
    _telemetry.log('map.cluster_tapped');
    // A UI deve usar esta sinalização para animar o zoom
  }

  // ---------------------------------------------------------------------------
  // Filtro de domínio
  // ---------------------------------------------------------------------------

  void updateFilter(AlertaFilter filter) {
    final currentState = state;
    if (currentState is! HomeLoaded) return;
    _lastFilter = null; // Invalida cache para forçar re-fetch com novo filtro
    _telemetry.log(
      'map.filter_applied',
      params: {
        'tipos': filter.tipos.map((t) => t.name).join(','),
        'hasDateFrom': filter.dateFrom != null,
        'hasDateTo': filter.dateTo != null,
      },
    );
    emit(currentState.copyWith(filter: filter));
  }

  void clearFilter() => updateFilter(const AlertaFilter());

  // ---------------------------------------------------------------------------
  // Viewport — onCameraIdle com debounce 300ms
  // ---------------------------------------------------------------------------

  /// Chamado pelo mapa sempre que a câmera para de se mover.
  ///
  /// - Debounce de 300ms para evitar chamadas excessivas durante o gesto.
  /// - Evita re-fetch se bounds, zoom e filtro não mudaram (cache hit).
  /// - Atualiza [currentZoom] no state para recalcular clusters.
  void onCameraIdle(LatLngBounds bounds, double zoom) {
    _cameraIdleDebounce?.cancel();
    _cameraIdleDebounce = Timer(
      const Duration(milliseconds: 300),
      () => _fetchInBounds(bounds, zoom),
    );
  }

  Future<void> _fetchInBounds(LatLngBounds bounds, double zoom) async {
    final currentState = state;
    if (currentState is! HomeLoaded) return;

    final geoBounds = GeoBounds(
      south: bounds.southwest.latitude,
      west: bounds.southwest.longitude,
      north: bounds.northeast.latitude,
      east: bounds.northeast.longitude,
    );

    // Cache hit: mesmos bounds, zoom e filtro → não re-busca
    if (_lastBounds != null &&
        _lastZoom != null &&
        _lastFilter != null &&
        _boundsEqual(geoBounds, _lastBounds!) &&
        (zoom - _lastZoom!).abs() < 0.5 &&
        currentState.filter == _lastFilter) {
      // Atualiza apenas o zoom para re-clusterizar
      if (currentState.currentZoom != zoom) {
        emit(currentState.copyWith(currentZoom: zoom));
      }
      return;
    }

    emit(currentState.copyWith(isLoadingPins: true, currentZoom: zoom));

    final result = await getAlertasInBoundsUseCase(
      GetAlertasInBoundsParams(
        bounds: bounds,
        zoom: zoom,
        filter: currentState.filter,
      ),
    );

    result.fold(
      (failure) {
        if (kDebugMode) {
          debugPrint('[HomeCubit] Falha na query por bounds: ${failure.message}');
        }
        _telemetry.log('map.viewport_query_failed');
        final latestState = state;
        if (latestState is HomeLoaded) {
          emit(latestState.copyWith(isLoadingPins: false));
        }
      },
      (alertas) {
        _lastBounds = geoBounds;
        _lastZoom = zoom;
        _lastFilter = currentState.filter;

        _telemetry.log(
          'map.viewport_loaded',
          params: {
            'zoom': zoom.toStringAsFixed(1),
            'pinCount': alertas.length,
          },
        );
        final latestState = state;
        if (latestState is HomeLoaded) {
          emit(latestState.copyWith(
            alertas: alertas,
            currentZoom: zoom,
            isLoadingPins: false,
          ));
        }
      },
    );
  }

  bool _boundsEqual(GeoBounds a, GeoBounds b) {
    const epsilon = 0.001;
    return (a.south - b.south).abs() < epsilon &&
        (a.north - b.north).abs() < epsilon &&
        (a.west - b.west).abs() < epsilon &&
        (a.east - b.east).abs() < epsilon;
  }

  @override
  Future<void> close() {
    _cameraIdleDebounce?.cancel();
    return super.close();
  }
}
