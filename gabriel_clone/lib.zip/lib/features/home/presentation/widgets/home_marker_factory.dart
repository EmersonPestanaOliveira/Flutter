import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../domain/entities/alerta.dart';
import '../../domain/entities/camera.dart';
import '../../domain/enums/alerta_tipo.dart';
import 'alert_pin_factory.dart';

abstract final class HomeMarkerFactory {
  static Marker camera({
    required Camera camera,
    required BitmapDescriptor? icon,
  }) {
    return Marker(
      markerId: MarkerId('camera_${camera.id}'),
      position: LatLng(camera.latitude, camera.longitude),
      icon: icon ?? BitmapDescriptor.defaultMarker,
      infoWindow: InfoWindow(
        title: camera.nome,
        snippet: camera.ativo ? 'Camera ativa' : 'Camera inativa',
      ),
    );
  }

  static Marker alerta({
    required Alerta alerta,
    required Map<AlertaTipo, BitmapDescriptor> icons,
    required ValueChanged<Alerta> onTap,
  }) {
    return Marker(
      markerId: MarkerId('alerta_${alerta.id}'),
      position: LatLng(alerta.latitude, alerta.longitude),
      icon:
          icons[alerta.tipo] ??
          BitmapDescriptor.defaultMarkerWithHue(
            AlertPinFactory.hue(alerta.tipo),
          ),
      anchor: const Offset(0.5, 0.5),
      onTap: () => onTap(alerta),
    );
  }
}
