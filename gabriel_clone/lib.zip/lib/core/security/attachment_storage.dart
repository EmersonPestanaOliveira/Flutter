import 'dart:io';

/// Abstração para armazenamento e proteção de anexos locais.
///
/// ## Estratégia de Segurança
///
/// Anexos de ocorrência (áudio, fotos, documentos) devem ser:
/// 1. Armazenados no diretório de documentos do app (não acessível por outras apps).
/// 2. Removidos após sincronização bem-sucedida.
/// 3. Nunca expostos em cache externo ou logs.
///
/// ## Implementação Recomendada (TODO: produção)
///
/// - Usar `getApplicationDocumentsDirectory()` para persistência.
/// - No iOS, usar o diretório `Library/Application Support` (não sincroniza com iCloud
///   por padrão e não aparece no "Files" app).
/// - Considerar criptografia de arquivo para alta sensibilidade (ex.: `EncryptedFile`
///   no Android via Jetpack Security ou `CommonCrypto` no iOS).
///
/// ## Implementação Atual
///
/// O [PlainAttachmentStorage] armazena em texto claro no diretório de documentos.
/// Substitua pela implementação criptografada antes do lançamento.
abstract interface class AttachmentStorage {
  /// Persiste o arquivo de [sourcePath] em armazenamento local seguro.
  ///
  /// Retorna o caminho persistido (pode ser diferente do source).
  Future<String> persist(String sourcePath, String clientId, String subfolder);

  /// Remove todos os anexos do [clientId] após sync confirmado.
  Future<void> cleanup(String clientId);

  /// Verifica se os anexos de [clientId] ainda existem localmente.
  Future<bool> exists(String clientId);
}

/// Implementação usando o diretório de documentos sem criptografia adicional.
///
/// Adequado para desenvolvimento. Para produção, adicione criptografia de arquivo.
class PlainAttachmentStorage implements AttachmentStorage {
  const PlainAttachmentStorage(this._baseDir);

  final String _baseDir;

  @override
  Future<String> persist(
    String sourcePath,
    String clientId,
    String subfolder,
  ) async {
    final attachDir = Directory('$_baseDir/ocorrencias/$clientId/$subfolder');
    await attachDir.create(recursive: true);

    final src = File(sourcePath);
    final fileName = src.path.split(Platform.pathSeparator).last;
    final destPath = '${attachDir.path}/$fileName';

    if (src.path == destPath) return sourcePath;
    await src.copy(destPath);
    return destPath;
  }

  @override
  Future<void> cleanup(String clientId) async {
    final dir = Directory('$_baseDir/ocorrencias/$clientId');
    if (await dir.exists()) {
      await dir.delete(recursive: true);
    }
  }

  @override
  Future<bool> exists(String clientId) async {
    final dir = Directory('$_baseDir/ocorrencias/$clientId');
    return dir.exists();
  }
}

// TODO(security): Implementar EncryptedAttachmentStorage
// class EncryptedAttachmentStorage implements AttachmentStorage {
//   // Criptografa cada arquivo individualmente com AES-256.
//   // Usar flutter_secure_storage para a chave e cryptography para o arquivo.
// }
