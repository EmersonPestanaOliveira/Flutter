/// Abstração para criptografia do payload JSON armazenado no SQLite.
///
/// ## Estratégia de Segurança
///
/// Dados de ocorrência (informações, localização, horário) são potencialmente
/// sensíveis. Em produção, o payload na coluna `payload_json` deve ser
/// criptografado em repouso usando AES-256-GCM com chave derivada do
/// Keystore do dispositivo.
///
/// ## Implementação Recomendada (TODO: produção)
///
/// - Android: `EncryptedSharedPreferences` via `flutter_secure_storage`
///   para armazenar a chave, + `EncryptedFile` ou `AesGcmSecretKey` para
///   o payload.
/// - iOS: `Keychain` via `flutter_secure_storage`, + AES do pacote `cryptography`.
/// - Pacote recomendado: `cryptography` (dart) ou `flutter_secure_storage`.
///
/// ## Implementação Atual
///
/// A [NoOpLocalPayloadCrypto] não criptografa — usada até a implementação
/// completa ser ativada. Substitua-a no container de DI sem alterar nenhum
/// outro código.
abstract interface class LocalPayloadCrypto {
  /// Criptografa [plainJson] antes de persistir no banco.
  Future<String> encrypt(String plainJson);

  /// Descriptografa [cipherText] ao ler do banco.
  Future<String> decrypt(String cipherText);
}

/// Implementação no-op para desenvolvimento/testes.
///
/// ATENÇÃO: NÃO use em produção com dados reais de usuário.
/// Substitua por [AesGcmLocalPayloadCrypto] antes do lançamento.
class NoOpLocalPayloadCrypto implements LocalPayloadCrypto {
  const NoOpLocalPayloadCrypto();

  @override
  Future<String> encrypt(String plainJson) async => plainJson;

  @override
  Future<String> decrypt(String cipherText) async => cipherText;
}

// TODO(security): Implementar AesGcmLocalPayloadCrypto
// class AesGcmLocalPayloadCrypto implements LocalPayloadCrypto {
//   AesGcmLocalPayloadCrypto(this._keyStore);
//   final SecureKeyStore _keyStore;
//
//   @override
//   Future<String> encrypt(String plainJson) async {
//     final key = await _keyStore.getOrCreateKey('ocorrencia_payload_key');
//     final algorithm = AesGcm.with256bits();
//     final secretKey = SecretKey(key);
//     final nonce = algorithm.newNonce();
//     final sealed = await algorithm.encryptString(
//       plainJson,
//       secretKey: secretKey,
//       nonce: nonce,
//     );
//     // Encoda nonce + ciphertext + MAC em base64
//     final bytes = [...nonce, ...sealed.cipherText, ...sealed.mac.bytes];
//     return base64Encode(bytes);
//   }
//
//   @override
//   Future<String> decrypt(String cipherText) async {
//     final key = await _keyStore.getOrCreateKey('ocorrencia_payload_key');
//     final bytes = base64Decode(cipherText);
//     // ... (decifra com AES-GCM)
//   }
// }
