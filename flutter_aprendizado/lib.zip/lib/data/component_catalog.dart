﻿import 'package:flutter/material.dart';
import '../models/component_item.dart';
import '../pages/component_playground_page.dart';

final List<ComponentItem> materialButtonComponents = [
  ComponentItem(
    title: 'ElevatedButton',
    icon: Icons.smart_button,
    pageBuilder: () => const ElevatedButtonPlayground(),
  ),
  ComponentItem(
    title: 'FilledButton',
    icon: Icons.rectangle,
    pageBuilder: () => const FilledButtonPlayground(),
  ),
  ComponentItem(
    title: 'FilledButton Tonal',
    icon: Icons.rectangle_outlined,
    pageBuilder: () => const FilledTonalButtonPlayground(),
  ),
  ComponentItem(
    title: 'OutlinedButton',
    icon: Icons.crop_square,
    pageBuilder: () => const OutlinedButtonPlayground(),
  ),
  ComponentItem(
    title: 'TextButton',
    icon: Icons.text_fields,
    pageBuilder: () => const TextButtonPlayground(),
  ),
  ComponentItem(
    title: 'IconButton',
    icon: Icons.ads_click,
    pageBuilder: () => const IconButtonPlayground(),
  ),
  ComponentItem(
    title: 'FAB',
    icon: Icons.add_circle,
    pageBuilder: () => const FloatingActionButtonPlayground(),
  ),
  ComponentItem(
    title: 'DropdownMenu',
    icon: Icons.arrow_drop_down_circle,
    pageBuilder: () => const DropdownMenuPlayground(),
  ),
];

final List<ComponentItem> materialInputComponents = [
  ComponentItem(
    title: 'TextField',
    icon: Icons.text_fields,
    pageBuilder: () => const TextFieldPlayground(),
  ),
];

final List<ComponentItem> materialFeedbackComponents = [
  ComponentItem(
    title: 'SnackBar',
    icon: Icons.message,
    pageBuilder: () => const SnackBarPlayground(),
  ),
];

final List<ComponentItem> materialSurfaceComponents = [
  ComponentItem(
    title: 'Card',
    icon: Icons.credit_card,
    pageBuilder: () => const CardPlayground(),
  ),
];

final List<ComponentItem> materialSelectionComponents = [
  ComponentItem(
    title: 'Checkbox',
    icon: Icons.check_box,
    pageBuilder: () => const CheckboxPlayground(),
  ),
  ComponentItem(
    title: 'Switch',
    icon: Icons.toggle_on,
    pageBuilder: () => const SwitchPlayground(),
  ),
  ComponentItem(
    title: 'Radio',
    icon: Icons.radio_button_checked,
    pageBuilder: () => const RadioPlayground(),
  ),
];

final List<ComponentItem> cupertinoComponents = [
  ComponentItem(
    title: 'CupertinoButton',
    icon: Icons.radio_button_checked,
    pageBuilder: () => const CupertinoButtonPlayground(),
  ),
];

final List<ComponentItem> layoutComponents = [
  ComponentItem(
    title: 'Container',
    icon: Icons.crop_square,
    pageBuilder: () => const ContainerPlayground(),
  ),
  ComponentItem(
    title: 'Row',
    icon: Icons.view_week,
    pageBuilder: () => const RowPlayground(),
  ),
];

final List<ComponentItem> baseScreensComponents = [
  ComponentItem(
    title: 'Login Screen',
    icon: Icons.login,
    pageBuilder: () => const LoginScreenPlayground(),
  ),
  ComponentItem(
    title: 'Profile Screen',
    icon: Icons.person,
    pageBuilder: () => const ProfileScreenPlayground(),
  ),
];
