﻿import 'package:flutter/material.dart';
import '../data/material_category_item.dart';
import '../pages/material_component_pages.dart';

final List<MaterialCategoryItem> materialCategories = [
  MaterialCategoryItem(
    title: 'Botões',
    icon: Icons.smart_button,
    page: const MaterialButtonsPage(),
  ),
  MaterialCategoryItem(
    title: 'Inputs',
    icon: Icons.text_fields,
    page: const MaterialInputsPage(),
  ),
  MaterialCategoryItem(
    title: 'Feedback',
    icon: Icons.notifications_active,
    page: const MaterialFeedbackPage(),
  ),
  MaterialCategoryItem(
    title: 'SuperfÃ­cie',
    icon: Icons.layers,
    page: const MaterialSurfacePage(),
  ),
  MaterialCategoryItem(
    title: 'SeleÃ§Ã£o',
    icon: Icons.checklist,
    page: const MaterialSelectionPage(),
  ),
];
