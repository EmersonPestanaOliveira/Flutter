﻿import 'package:flutter/material.dart';

class MaterialCategoryItem {
  final String title;
  final IconData icon;
  final Widget page;

  const MaterialCategoryItem({
    required this.title,
    required this.icon,
    required this.page,
  });
}
