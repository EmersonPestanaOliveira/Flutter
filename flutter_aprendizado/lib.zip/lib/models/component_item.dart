﻿import 'package:flutter/material.dart';

class ComponentItem {
  final String title;
  final IconData icon;
  final Widget Function() pageBuilder;

  const ComponentItem({
    required this.title,
    required this.icon,
    required this.pageBuilder,
  });
}
