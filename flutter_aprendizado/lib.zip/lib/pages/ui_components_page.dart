﻿import 'package:flutter/material.dart';
import 'material_categories_page.dart';
import 'cupertino_components_page.dart';
import 'layout_components_page.dart';
import 'base_screens_page.dart';

class UIComponentsPage extends StatelessWidget {
  const UIComponentsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      _CategoryCardData(
        title: 'Material',
        icon: Icons.widgets,
        page: const MaterialCategoriesPage(),
      ),
      _CategoryCardData(
        title: 'Cupertino',
        icon: Icons.phone_iphone,
        page: const CupertinoComponentsPage(),
      ),
      _CategoryCardData(
        title: 'Layout',
        icon: Icons.grid_view,
        page: const LayoutComponentsPage(),
      ),
      _CategoryCardData(
        title: 'Telas Base',
        icon: Icons.web,
        page: const BaseScreensPage(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('UI Components')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.builder(
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.05,
          ),
          itemBuilder: (context, index) {
            final item = items[index];
            return InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => item.page),
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.blue.shade50,
                  border: Border.all(color: Colors.blue.shade100),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(item.icon, size: 44, color: Colors.blue),
                    const SizedBox(height: 12),
                    Text(
                      item.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _CategoryCardData {
  final String title;
  final IconData icon;
  final Widget page;

  _CategoryCardData({
    required this.title,
    required this.icon,
    required this.page,
  });
}
