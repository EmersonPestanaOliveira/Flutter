﻿import 'package:flutter/material.dart';
import '../data/component_catalog.dart';
import 'category_grid_page.dart';

class BaseScreensPage extends StatelessWidget {
  const BaseScreensPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Telas Base',
      items: baseScreensComponents,
    );
  }
}
