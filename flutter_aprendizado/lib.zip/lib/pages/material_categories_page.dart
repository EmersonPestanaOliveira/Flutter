﻿import 'package:flutter/material.dart';
import '../data/material_categories_catalog.dart';
import 'material_category_grid_page.dart';

class MaterialCategoriesPage extends StatelessWidget {
  const MaterialCategoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialCategoryGridPage(
      title: 'Material',
      items: materialCategories,
    );
  }
}
