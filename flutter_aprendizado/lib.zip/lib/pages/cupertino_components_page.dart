﻿import 'package:flutter/material.dart';
import '../data/component_catalog.dart';
import 'category_grid_page.dart';

class CupertinoComponentsPage extends StatelessWidget {
  const CupertinoComponentsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Cupertino',
      items: cupertinoComponents,
    );
  }
}
