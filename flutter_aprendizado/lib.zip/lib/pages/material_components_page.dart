﻿import 'package:flutter/material.dart';
import 'material_categories_page.dart';

class MaterialComponentsPage extends StatelessWidget {
  const MaterialComponentsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialCategoriesPage();
  }
}
