﻿import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ElevatedButtonPlayground extends StatefulWidget {
  const ElevatedButtonPlayground({super.key});

  @override
  State<ElevatedButtonPlayground> createState() =>
      _ElevatedButtonPlaygroundState();
}

class _ElevatedButtonPlaygroundState extends State<ElevatedButtonPlayground> {
  String label = 'ElevatedButton';
  bool enabled = true;
  bool showIcon = false;
  bool useMinimumSize = true;
  bool useFixedSize = false;

  double fontSize = 16;
  double borderRadius = 12;
  double elevation = 1;
  double horizontalPadding = 20;
  double verticalPadding = 14;
  double minWidth = 180;
  double minHeight = 48;
  double fixedWidth = 220;
  double fixedHeight = 52;
  double borderWidth = 1;

  String backgroundColorName = 'blue';
  String foregroundColorName = 'white';
  String borderColorName = 'blue';
  String alignmentName = 'center';
  String clipBehaviorName = 'none';

  final Map<String, Color> colorOptions = {
    'blue': Colors.blue,
    'red': Colors.red,
    'green': Colors.green,
    'orange': Colors.orange,
    'purple': Colors.purple,
    'black': Colors.black,
    'white': Colors.white,
    'grey': Colors.grey,
    'teal': Colors.teal,
    'pink': Colors.pink,
  };

  final Map<String, AlignmentGeometry> alignmentOptions = {
    'start': Alignment.centerLeft,
    'center': Alignment.center,
    'end': Alignment.centerRight,
  };

  final Map<String, Clip> clipOptions = {
    'none': Clip.none,
    'hardEdge': Clip.hardEdge,
    'antiAlias': Clip.antiAlias,
  };

  @override
  Widget build(BuildContext context) {
    final backgroundColor = colorOptions[backgroundColorName]!;
    final foregroundColor = colorOptions[foregroundColorName]!;
    final borderColor = colorOptions[borderColorName]!;
    final alignment = alignmentOptions[alignmentName]!;
    final clipBehavior = clipOptions[clipBehaviorName]!;

    final style = ButtonStyle(
      backgroundColor: MaterialStatePropertyAll(backgroundColor),
      foregroundColor: MaterialStatePropertyAll(foregroundColor),
      elevation: MaterialStatePropertyAll(elevation),
      padding: MaterialStatePropertyAll(
        EdgeInsets.symmetric(
          horizontal: horizontalPadding,
          vertical: verticalPadding,
        ),
      ),
      minimumSize: useMinimumSize
          ? MaterialStatePropertyAll(Size(minWidth, minHeight))
          : null,
      fixedSize: useFixedSize
          ? MaterialStatePropertyAll(Size(fixedWidth, fixedHeight))
          : null,
      alignment: alignment,
      side: MaterialStatePropertyAll(
        BorderSide(
          color: borderColor,
          width: borderWidth,
        ),
      ),
      shape: MaterialStatePropertyAll(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(borderRadius),
        ),
      ),
    );

    final Widget previewButton = showIcon
        ? ElevatedButton.icon(
            onPressed: enabled ? () {} : null,
            icon: const Icon(Icons.fitness_center),
            label: Text(
              label,
              style: TextStyle(fontSize: fontSize),
            ),
            style: style,
            clipBehavior: clipBehavior,
          )
        : ElevatedButton(
            onPressed: enabled ? () {} : null,
            style: style,
            clipBehavior: clipBehavior,
            child: Text(
              label,
              style: TextStyle(fontSize: fontSize),
            ),
          );

    return Scaffold(
      appBar: AppBar(title: const Text('ElevatedButton')),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: previewButton,
              ),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                TextField(
                  controller: TextEditingController(text: label)
                    ..selection = TextSelection.collapsed(
                      offset: label.length,
                    ),
                  decoration: const InputDecoration(
                    labelText: 'Texto',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      label = value.isEmpty ? 'ElevatedButton' : value;
                    });
                  },
                ),
                const SizedBox(height: 12),
                SwitchListTile(
                  title: const Text('Habilitado'),
                  value: enabled,
                  onChanged: (value) => setState(() => enabled = value),
                ),
                SwitchListTile(
                  title: const Text('Mostrar Ã­cone'),
                  value: showIcon,
                  onChanged: (value) => setState(() => showIcon = value),
                ),
                const SizedBox(height: 8),
                Text('Font size: ${fontSize.toStringAsFixed(0)}'),
                Slider(
                  min: 10,
                  max: 32,
                  value: fontSize,
                  onChanged: (value) => setState(() => fontSize = value),
                ),
                Text('Border radius: ${borderRadius.toStringAsFixed(0)}'),
                Slider(
                  min: 0,
                  max: 40,
                  value: borderRadius,
                  onChanged: (value) => setState(() => borderRadius = value),
                ),
                Text('Elevation: ${elevation.toStringAsFixed(1)}'),
                Slider(
                  min: 0,
                  max: 20,
                  value: elevation,
                  onChanged: (value) => setState(() => elevation = value),
                ),
                Text('Padding horizontal: ${horizontalPadding.toStringAsFixed(0)}'),
                Slider(
                  min: 0,
                  max: 40,
                  value: horizontalPadding,
                  onChanged: (value) => setState(() => horizontalPadding = value),
                ),
                Text('Padding vertical: ${verticalPadding.toStringAsFixed(0)}'),
                Slider(
                  min: 0,
                  max: 30,
                  value: verticalPadding,
                  onChanged: (value) => setState(() => verticalPadding = value),
                ),
                Text('Borda: ${borderWidth.toStringAsFixed(1)}'),
                Slider(
                  min: 0,
                  max: 6,
                  value: borderWidth,
                  onChanged: (value) => setState(() => borderWidth = value),
                ),
                const SizedBox(height: 12),
                SwitchListTile(
                  title: const Text('Usar minimumSize'),
                  value: useMinimumSize,
                  onChanged: (value) => setState(() => useMinimumSize = value),
                ),
                if (useMinimumSize) ...[
                  Text('Minimum width: ${minWidth.toStringAsFixed(0)}'),
                  Slider(
                    min: 60,
                    max: 320,
                    value: minWidth,
                    onChanged: (value) => setState(() => minWidth = value),
                  ),
                  Text('Minimum height: ${minHeight.toStringAsFixed(0)}'),
                  Slider(
                    min: 36,
                    max: 100,
                    value: minHeight,
                    onChanged: (value) => setState(() => minHeight = value),
                  ),
                ],
                const SizedBox(height: 12),
                SwitchListTile(
                  title: const Text('Usar fixedSize'),
                  value: useFixedSize,
                  onChanged: (value) => setState(() => useFixedSize = value),
                ),
                if (useFixedSize) ...[
                  Text('Fixed width: ${fixedWidth.toStringAsFixed(0)}'),
                  Slider(
                    min: 80,
                    max: 340,
                    value: fixedWidth,
                    onChanged: (value) => setState(() => fixedWidth = value),
                  ),
                  Text('Fixed height: ${fixedHeight.toStringAsFixed(0)}'),
                  Slider(
                    min: 36,
                    max: 120,
                    value: fixedHeight,
                    onChanged: (value) => setState(() => fixedHeight = value),
                  ),
                ],
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: backgroundColorName,
                  decoration: const InputDecoration(
                    labelText: 'Background color',
                    border: OutlineInputBorder(),
                  ),
                  items: colorOptions.keys
                      .map(
                        (key) => DropdownMenuItem(
                          value: key,
                          child: Text(key),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => backgroundColorName = value);
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: foregroundColorName,
                  decoration: const InputDecoration(
                    labelText: 'Foreground color',
                    border: OutlineInputBorder(),
                  ),
                  items: colorOptions.keys
                      .map(
                        (key) => DropdownMenuItem(
                          value: key,
                          child: Text(key),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => foregroundColorName = value);
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: borderColorName,
                  decoration: const InputDecoration(
                    labelText: 'Border color',
                    border: OutlineInputBorder(),
                  ),
                  items: colorOptions.keys
                      .map(
                        (key) => DropdownMenuItem(
                          value: key,
                          child: Text(key),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => borderColorName = value);
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: alignmentName,
                  decoration: const InputDecoration(
                    labelText: 'Alignment',
                    border: OutlineInputBorder(),
                  ),
                  items: alignmentOptions.keys
                      .map(
                        (key) => DropdownMenuItem(
                          value: key,
                          child: Text(key),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => alignmentName = value);
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: clipBehaviorName,
                  decoration: const InputDecoration(
                    labelText: 'Clip behavior',
                    border: OutlineInputBorder(),
                  ),
                  items: clipOptions.keys
                      .map(
                        (key) => DropdownMenuItem(
                          value: key,
                          child: Text(key),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => clipBehaviorName = value);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FilledButtonPlayground extends StatefulWidget {
  const FilledButtonPlayground({super.key});

  @override
  State<FilledButtonPlayground> createState() => _FilledButtonPlaygroundState();
}

class _FilledButtonPlaygroundState extends State<FilledButtonPlayground> {
  String label = 'FilledButton';
  double fontSize = 16;
  double radius = 12;
  bool enabled = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'FilledButton',
      preview: FilledButton(
        onPressed: enabled ? () {} : null,
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radius),
          ),
        ),
        child: Text(label, style: TextStyle(fontSize: fontSize)),
      ),
      controls: [
        _textControl('Texto', label, (v) => setState(() => label = v.isEmpty ? 'FilledButton' : v)),
        _sliderControl('Font size', fontSize, 10, 30, (v) => setState(() => fontSize = v)),
        _sliderControl('Radius', radius, 0, 32, (v) => setState(() => radius = v)),
        SwitchListTile(
          title: const Text('Habilitado'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
      ],
    );
  }
}

class FilledTonalButtonPlayground extends StatefulWidget {
  const FilledTonalButtonPlayground({super.key});

  @override
  State<FilledTonalButtonPlayground> createState() => _FilledTonalButtonPlaygroundState();
}

class _FilledTonalButtonPlaygroundState extends State<FilledTonalButtonPlayground> {
  String label = 'FilledButton Tonal';
  double fontSize = 16;
  double radius = 12;
  bool enabled = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'FilledButton Tonal',
      preview: FilledButton.tonal(
        onPressed: enabled ? () {} : null,
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radius),
          ),
        ),
        child: Text(label, style: TextStyle(fontSize: fontSize)),
      ),
      controls: [
        _textControl('Texto', label, (v) => setState(() => label = v.isEmpty ? 'FilledButton Tonal' : v)),
        _sliderControl('Font size', fontSize, 10, 30, (v) => setState(() => fontSize = v)),
        _sliderControl('Radius', radius, 0, 32, (v) => setState(() => radius = v)),
        SwitchListTile(
          title: const Text('Habilitado'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
      ],
    );
  }
}

class OutlinedButtonPlayground extends StatefulWidget {
  const OutlinedButtonPlayground({super.key});

  @override
  State<OutlinedButtonPlayground> createState() => _OutlinedButtonPlaygroundState();
}

class _OutlinedButtonPlaygroundState extends State<OutlinedButtonPlayground> {
  String label = 'OutlinedButton';
  double fontSize = 16;
  double radius = 12;
  bool enabled = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'OutlinedButton',
      preview: OutlinedButton(
        onPressed: enabled ? () {} : null,
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radius),
          ),
        ),
        child: Text(label, style: TextStyle(fontSize: fontSize)),
      ),
      controls: [
        _textControl('Texto', label, (v) => setState(() => label = v.isEmpty ? 'OutlinedButton' : v)),
        _sliderControl('Font size', fontSize, 10, 30, (v) => setState(() => fontSize = v)),
        _sliderControl('Radius', radius, 0, 32, (v) => setState(() => radius = v)),
        SwitchListTile(
          title: const Text('Habilitado'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
      ],
    );
  }
}

class TextButtonPlayground extends StatefulWidget {
  const TextButtonPlayground({super.key});

  @override
  State<TextButtonPlayground> createState() => _TextButtonPlaygroundState();
}

class _TextButtonPlaygroundState extends State<TextButtonPlayground> {
  String label = 'TextButton';
  double fontSize = 16;
  bool enabled = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'TextButton',
      preview: TextButton(
        onPressed: enabled ? () {} : null,
        child: Text(label, style: TextStyle(fontSize: fontSize)),
      ),
      controls: [
        _textControl('Texto', label, (v) => setState(() => label = v.isEmpty ? 'TextButton' : v)),
        _sliderControl('Font size', fontSize, 10, 30, (v) => setState(() => fontSize = v)),
        SwitchListTile(
          title: const Text('Habilitado'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
      ],
    );
  }
}

class IconButtonPlayground extends StatefulWidget {
  const IconButtonPlayground({super.key});

  @override
  State<IconButtonPlayground> createState() => _IconButtonPlaygroundState();
}

class _IconButtonPlaygroundState extends State<IconButtonPlayground> {
  double iconSize = 28;
  bool selected = false;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'IconButton',
      preview: IconButton.filled(
        isSelected: selected,
        onPressed: () {},
        iconSize: iconSize,
        selectedIcon: const Icon(Icons.favorite),
        icon: const Icon(Icons.favorite_border),
      ),
      controls: [
        _sliderControl('Icon size', iconSize, 16, 48, (v) => setState(() => iconSize = v)),
        SwitchListTile(
          title: const Text('Selecionado'),
          value: selected,
          onChanged: (v) => setState(() => selected = v),
        ),
      ],
    );
  }
}

class FloatingActionButtonPlayground extends StatefulWidget {
  const FloatingActionButtonPlayground({super.key});

  @override
  State<FloatingActionButtonPlayground> createState() => _FloatingActionButtonPlaygroundState();
}

class _FloatingActionButtonPlaygroundState extends State<FloatingActionButtonPlayground> {
  bool extended = false;
  String label = 'Adicionar';

  @override
  Widget build(BuildContext context) {
    final Widget fab = extended
        ? FloatingActionButton.extended(
            onPressed: () {},
            icon: const Icon(Icons.add),
            label: Text(label),
          )
        : FloatingActionButton(
            onPressed: () {},
            child: const Icon(Icons.add),
          );

    return _PlaygroundScaffold(
      title: 'FloatingActionButton',
      preview: fab,
      controls: [
        SwitchListTile(
          title: const Text('VersÃ£o extended'),
          value: extended,
          onChanged: (v) => setState(() => extended = v),
        ),
        if (extended)
          _textControl('Texto', label, (v) => setState(() => label = v.isEmpty ? 'Adicionar' : v)),
      ],
    );
  }
}

class DropdownMenuPlayground extends StatefulWidget {
  const DropdownMenuPlayground({super.key});

  @override
  State<DropdownMenuPlayground> createState() => _DropdownMenuPlaygroundState();
}

class _DropdownMenuPlaygroundState extends State<DropdownMenuPlayground> {
  String? selected;
  bool enabled = true;
  final items = ['Peito', 'Costas', 'Perna', 'Cardio'];

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'DropdownMenu',
      preview: SizedBox(
        width: 260,
        child: DropdownMenu<String>(
          enabled: enabled,
          initialSelection: selected,
          onSelected: (value) => setState(() => selected = value),
          dropdownMenuEntries: items
              .map((e) => DropdownMenuEntry<String>(value: e, label: e))
              .toList(),
        ),
      ),
      controls: [
        SwitchListTile(
          title: const Text('Habilitado'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
      ],
    );
  }
}

class TextFieldPlayground extends StatefulWidget {
  const TextFieldPlayground({super.key});

  @override
  State<TextFieldPlayground> createState() => _TextFieldPlaygroundState();
}

class _TextFieldPlaygroundState extends State<TextFieldPlayground> {
  String label = 'Seu nome';
  String hint = 'Digite aqui';
  bool obscureText = false;
  bool enabled = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'TextField',
      preview: SizedBox(
        width: 280,
        child: TextField(
          enabled: enabled,
          obscureText: obscureText,
          decoration: InputDecoration(
            labelText: label,
            hintText: hint,
            border: const OutlineInputBorder(),
          ),
        ),
      ),
      controls: [
        _textControl('Label', label, (v) => setState(() => label = v)),
        _textControl('Hint', hint, (v) => setState(() => hint = v)),
        SwitchListTile(
          title: const Text('Obscure text'),
          value: obscureText,
          onChanged: (v) => setState(() => obscureText = v),
        ),
        SwitchListTile(
          title: const Text('Enabled'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
      ],
    );
  }
}

class SnackBarPlayground extends StatelessWidget {
  const SnackBarPlayground({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SnackBar')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Exemplo de SnackBar')),
            );
          },
          child: const Text('Mostrar SnackBar'),
        ),
      ),
    );
  }
}

class CardPlayground extends StatefulWidget {
  const CardPlayground({super.key});

  @override
  State<CardPlayground> createState() => _CardPlaygroundState();
}

class _CardPlaygroundState extends State<CardPlayground> {
  double elevation = 4;
  double radius = 16;
  String title = 'TÃ­tulo do Card';

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Card',
      preview: Card(
        elevation: elevation,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius),
        ),
        child: SizedBox(
          width: 280,
          height: 140,
          child: Center(
            child: Text(title, style: const TextStyle(fontSize: 20)),
          ),
        ),
      ),
      controls: [
        _textControl('TÃ­tulo', title, (v) => setState(() => title = v)),
        _sliderControl('Elevation', elevation, 0, 20, (v) => setState(() => elevation = v)),
        _sliderControl('Radius', radius, 0, 40, (v) => setState(() => radius = v)),
      ],
    );
  }
}

class CheckboxPlayground extends StatefulWidget {
  const CheckboxPlayground({super.key});

  @override
  State<CheckboxPlayground> createState() => _CheckboxPlaygroundState();
}

class _CheckboxPlaygroundState extends State<CheckboxPlayground> {
  bool value = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Checkbox',
      preview: Checkbox(
        value: value,
        onChanged: (v) => setState(() => value = v ?? false),
      ),
      controls: [
        SwitchListTile(
          title: const Text('Marcado'),
          value: value,
          onChanged: (v) => setState(() => value = v),
        ),
      ],
    );
  }
}

class SwitchPlayground extends StatefulWidget {
  const SwitchPlayground({super.key});

  @override
  State<SwitchPlayground> createState() => _SwitchPlaygroundState();
}

class _SwitchPlaygroundState extends State<SwitchPlayground> {
  bool value = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Switch',
      preview: Switch(
        value: value,
        onChanged: (v) => setState(() => value = v),
      ),
      controls: [
        SwitchListTile(
          title: const Text('Ligado'),
          value: value,
          onChanged: (v) => setState(() => value = v),
        ),
      ],
    );
  }
}

class RadioPlayground extends StatefulWidget {
  const RadioPlayground({super.key});

  @override
  State<RadioPlayground> createState() => _RadioPlaygroundState();
}

class _RadioPlaygroundState extends State<RadioPlayground> {
  String value = 'A';

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Radio',
      preview: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          RadioListTile<String>(
            title: const Text('OpÃ§Ã£o A'),
            value: 'A',
            groupValue: value,
            onChanged: (v) => setState(() => value = v!),
          ),
          RadioListTile<String>(
            title: const Text('OpÃ§Ã£o B'),
            value: 'B',
            groupValue: value,
            onChanged: (v) => setState(() => value = v!),
          ),
        ],
      ),
      controls: [
        ListTile(
          title: Text('Selecionado: $value'),
        ),
      ],
    );
  }
}

class CupertinoButtonPlayground extends StatefulWidget {
  const CupertinoButtonPlayground({super.key});

  @override
  State<CupertinoButtonPlayground> createState() => _CupertinoButtonPlaygroundState();
}

class _CupertinoButtonPlaygroundState extends State<CupertinoButtonPlayground> {
  String text = 'Cupertino Button';
  double padding = 16;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'CupertinoButton',
      preview: CupertinoButton(
        padding: EdgeInsets.symmetric(horizontal: padding, vertical: 12),
        color: CupertinoColors.activeBlue,
        onPressed: () {},
        child: Text(text),
      ),
      controls: [
        _textControl('Texto', text, (v) => setState(() => text = v)),
        _sliderControl('Padding', padding, 8, 40, (v) => setState(() => padding = v)),
      ],
    );
  }
}

class ContainerPlayground extends StatefulWidget {
  const ContainerPlayground({super.key});

  @override
  State<ContainerPlayground> createState() => _ContainerPlaygroundState();
}

class _ContainerPlaygroundState extends State<ContainerPlayground> {
  double width = 160;
  double height = 120;
  double radius = 16;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Container',
      preview: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: Colors.blue,
          borderRadius: BorderRadius.circular(radius),
        ),
      ),
      controls: [
        _sliderControl('Width', width, 50, 300, (v) => setState(() => width = v)),
        _sliderControl('Height', height, 50, 300, (v) => setState(() => height = v)),
        _sliderControl('Border radius', radius, 0, 50, (v) => setState(() => radius = v)),
      ],
    );
  }
}

class RowPlayground extends StatefulWidget {
  const RowPlayground({super.key});

  @override
  State<RowPlayground> createState() => _RowPlaygroundState();
}

class _RowPlaygroundState extends State<RowPlayground> {
  double spacing = 8;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Row',
      preview: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _box(),
          SizedBox(width: spacing),
          _box(),
          SizedBox(width: spacing),
          _box(),
        ],
      ),
      controls: [
        _sliderControl('Spacing', spacing, 0, 40, (v) => setState(() => spacing = v)),
      ],
    );
  }

  Widget _box() {
    return Container(
      width: 50,
      height: 50,
      color: Colors.blue,
    );
  }
}

class LoginScreenPlayground extends StatefulWidget {
  const LoginScreenPlayground({super.key});

  @override
  State<LoginScreenPlayground> createState() => _LoginScreenPlaygroundState();
}

class _LoginScreenPlaygroundState extends State<LoginScreenPlayground> {
  String title = 'Login';
  bool showSubtitle = true;

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Login Screen',
      preview: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            if (showSubtitle) ...[
              const SizedBox(height: 8),
              const Text('Entre para continuar'),
            ],
            const SizedBox(height: 24),
            const TextField(
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            const TextField(
              decoration: InputDecoration(
                labelText: 'Senha',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {},
                child: const Text('Entrar'),
              ),
            ),
          ],
        ),
      ),
      controls: [
        _textControl('TÃ­tulo', title, (v) => setState(() => title = v)),
        SwitchListTile(
          title: const Text('Mostrar subtÃ­tulo'),
          value: showSubtitle,
          onChanged: (v) => setState(() => showSubtitle = v),
        ),
      ],
    );
  }
}

class ProfileScreenPlayground extends StatefulWidget {
  const ProfileScreenPlayground({super.key});

  @override
  State<ProfileScreenPlayground> createState() => _ProfileScreenPlaygroundState();
}

class _ProfileScreenPlaygroundState extends State<ProfileScreenPlayground> {
  String name = 'Seu Nome';
  String bio = 'Sua bio aqui';

  @override
  Widget build(BuildContext context) {
    return _PlaygroundScaffold(
      title: 'Profile Screen',
      preview: ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.all(24),
        children: [
          const CircleAvatar(
            radius: 48,
            child: Icon(Icons.person, size: 48),
          ),
          const SizedBox(height: 16),
          Text(
            name,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            bio,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Card(
            child: ListTile(
              leading: const Icon(Icons.fitness_center),
              title: const Text('Treinos'),
              subtitle: const Text('12 concluÃ­dos'),
            ),
          ),
        ],
      ),
      controls: [
        _textControl('Nome', name, (v) => setState(() => name = v)),
        _textControl('Bio', bio, (v) => setState(() => bio = v)),
      ],
    );
  }
}

class _PlaygroundScaffold extends StatelessWidget {
  final String title;
  final Widget preview;
  final List<Widget> controls;

  const _PlaygroundScaffold({
    required this.title,
    required this.preview,
    required this.controls,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Column(
        children: [
          Expanded(
            child: Center(child: SingleChildScrollView(child: preview)),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: controls,
            ),
          ),
        ],
      ),
    );
  }
}

Widget _textControl(String label, String value, ValueChanged<String> onChanged) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(
      controller: TextEditingController(text: value)
        ..selection = TextSelection.collapsed(offset: value.length),
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      onChanged: onChanged,
    ),
  );
}

Widget _sliderControl(
  String label,
  double value,
  double min,
  double max,
  ValueChanged<double> onChanged,
) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: ${value.toStringAsFixed(0)}'),
        Slider(
          min: min,
          max: max,
          value: value.clamp(min, max),
          onChanged: onChanged,
        ),
      ],
    ),
  );
}


