﻿import 'package:flutter/material.dart';
import 'ui_components_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UIComponentsPage()),
            );
          },
          child: const Text('Abrir UI Components'),
        ),
      ),
    );
  }
}
