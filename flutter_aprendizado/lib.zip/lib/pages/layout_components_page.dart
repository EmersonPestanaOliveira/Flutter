﻿import 'package:flutter/material.dart';
import '../data/component_catalog.dart';
import 'category_grid_page.dart';

class LayoutComponentsPage extends StatelessWidget {
  const LayoutComponentsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Layout',
      items: layoutComponents,
    );
  }
}
