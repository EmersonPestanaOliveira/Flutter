﻿import 'package:flutter/material.dart';
import '../data/component_catalog.dart';
import 'category_grid_page.dart';

class MaterialButtonsPage extends StatelessWidget {
  const MaterialButtonsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Material / Botões',
      items: materialButtonComponents,
    );
  }
}

class MaterialInputsPage extends StatelessWidget {
  const MaterialInputsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Material / Inputs',
      items: materialInputComponents,
    );
  }
}

class MaterialFeedbackPage extends StatelessWidget {
  const MaterialFeedbackPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Material / Feedback',
      items: materialFeedbackComponents,
    );
  }
}

class MaterialSurfacePage extends StatelessWidget {
  const MaterialSurfacePage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Material / SuperfÃ­cie',
      items: materialSurfaceComponents,
    );
  }
}

class MaterialSelectionPage extends StatelessWidget {
  const MaterialSelectionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CategoryGridPage(
      title: 'Material / SeleÃ§Ã£o',
      items: materialSelectionComponents,
    );
  }
}
